# Defaults und automatische Auftragsnormalisierung
## Werte ohne Rückfrage ergänzen
Sprache: Deutsch. Zielgruppe: Top-Management und Gesprächsvorbereitung.
Stichtag: tatsächliches aktuelles Datum der Laufumgebung (YYYY-MM-DD).
Unternehmensgrenze: eindeutig identifizierte Unternehmensgruppe und relevante,
öffentlich belegte Gesellschaften/Partner. Offizielle Firmenwebsite recherchieren.
Grundblick: global; Nutzerthemen bestimmen die vertieften regionalen Schwerpunkte.
Ausgabe: output/briefing.html, output/abnahme.md; kompakt mit aufklappbaren vertiefenden Details.
Quellen: öffentlich, möglichst primär und zum Stichtag passend.
Rechercheumfang: entscheidungsrelevante Befunde, keine Vollständigkeit behaupten.
Nutzerangaben überschreiben Defaults; nie fehlende Person/Region hinzuerfinden.

## Aus kurzer Nachricht input/auftrag.md anlegen
Originalnachricht unverändert dokumentieren. Zusätzlich normalisierte Felder:
Unternehmen, offizielle Website, Unternehmensgrenze, Stichtag, Sprache,
Zielgruppe, Grundregion, priorisierte Themen in Nutzerreihenfolge,
Gesprächspartner (falls genannt), Position laut Nutzer, Verifizierungsstatus,
Pflichtmodule, Ausgabeziele und Quellenstandard.
Firma zuerst eindeutig zuordnen; bei gleichnamigen Firmen mit relevantem
Unterschied gezielt nachfragen. Themen nicht als bereits belegte Tatsachen lesen.
Kein Nutzerthema: allgemeines Firmenbriefing. Keine Person: Profilabschnitt entfällt.
Nutzer-Position ist anfangs „Nutzerangabe, noch nicht verifiziert“.
Keine feste Beispiel-Firma und keinen festen Stichtag in Defaults eintragen.

## Wiederholte Aufträge
Vor neuem Lauf vorhandene input/auftrag.md, work/ und output/ unter
archive/<Zeitstempel>-<Firmenname>/ sichern; keine alten Claims übernehmen.
Gleichen Stichtag/Firmenbezug in allen neuen Modulköpfen prüfen.
Kein erfolgreicher Vorgänger oder Gesprächsverlauf allein aus „auch“ ableiten.

## Neue vollständige HTML-Briefings (v2)
Pfade runs/<neue_run_id>/input/, work/, output/; frühere Läufe erhalten.
Ausgabe nach ausgabe-html-v2.md. Root-/Archivregeln oben nur für ausdrücklich
bestehende Legacy-Markdown-Läufe. Einrichtung erzeugt keinen Firmenauftrag.

## Portfolio und Themenumfang
Vollbriefing: unternehmensweites Portfolio als Standard. Allgemeine
Unternehmensthemen nach themen-darstellung.md. Separate Themen-/Markt-/Länder-
überblicke nach fokusseiten.md: ein Reiter und eigener focus-analyst-Aufruf je
Fokusthema, Sonnet 5.5 Medium. Neue Manifestdateien immer mit focus_pages (sonst []).
Jeder neue Fokus erhält briefing_type="topic_market": neutrales Themen- und
Marktbriefing mit Grundlagen, Kennzahlen, Segmenten, Akteuren und Meetingfragen
nach fokusseiten.md. Dies muss nicht im Nutzerprompt wiederholt werden.
Unter Portfolio, Cluster und Markt/Wettbewerb auf Seite 1 je 1–3 geprüfte
Fakt/Insight-Karten nach modul-keyfacts.md; Auswahl in bestehender Positionierung.
Regionale Unternehmenspräsenz nach regionale-praesenz.md im Vollbriefing auf
Seite 1 vor Wettbewerb; Firmen-/Regionsdaten neu recherchieren, fixe Skala 1–5.

## Zeitfenster aktueller Entwicklungen
Im Unternehmensüberblick nur die letzten vier Kalendermonate bis zum Stichtag
(inklusive) nach ausgabe-html-v2.md recherchieren und anzeigen. Keine pauschale
Altersgrenze für die übrige Faktenbasis. Fokusseiten behalten sechs Monate;
Gesprächspartner-Medien folgen unverändert gespraechspartner.md.
